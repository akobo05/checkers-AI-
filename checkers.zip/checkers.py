import threading
import time
import copy
# Importamos ProcessPoolExecutor para el paralelismo real
from concurrent.futures import ProcessPoolExecutor

# --- Constantes y Configuración del Tablero (sin cambios) ---
WHITE = 'W'
BLACK = 'B'
WHITE_KING = 'WK'
BLACK_KING = 'BK'
EMPTY = ' '
memoization_cache = {}
# El lock solo es necesario para la versión con hilos
parallel_search_lock = threading.Lock()


# --- Funciones de inicialización e impresión (sin cambios) ---
def initialize_board():
    board = [[EMPTY for _ in range(8)] for _ in range(8)]
    for row in range(3):
        for col in range(8):
            if (row + col) % 2 == 1:
                board[row][col] = BLACK
    for row in range(5, 8):
        for col in range(8):
            if (row + col) % 2 == 1:
                board[row][col] = WHITE
    return board


def print_board(board):
    print("\n   A  B  C  D  E  F  G  H")
    print(" +-----------------+")
    for i, row in enumerate(board):
        print(f"{8 - i}| {' '.join(p.ljust(2) for p in row)}|")
    print(" +-----------------+")


# --- Lógica del Juego y Movimientos (sin cambios) ---
def get_possible_moves(board, player):
    moves = []
    capture_moves = []
    for r in range(8):
        for c in range(8):
            piece = board[r][c]
            if piece.upper().startswith(player):
                _get_piece_moves(board, r, c, moves, capture_moves)
    return capture_moves if capture_moves else moves


def get_captures_from_position(board, position):
    """
    Busca y devuelve únicamente los movimientos de captura posibles desde una posición dada.
    """
    r, c = position
    # Si no hay pieza en la posición, no hay movimientos.
    if board[r][c] == EMPTY:
        return []

    capture_moves = []
    # Reutilizamos la lógica de _get_piece_moves, pero solo nos interesan las capturas.
    # El primer [] es para los movimientos simples, que ignoraremos.
    _get_piece_moves(board, r, c, [], capture_moves)

    return capture_moves


def _get_piece_moves(board, r, c, moves, capture_moves):
    piece = board[r][c]
    is_king = len(piece) == 2
    player = piece[0]
    move_dirs = [(-1, -1), (-1, 1)] if player == WHITE else [(1, -1), (1, 1)]
    if is_king:
        move_dirs += [(1, -1), (1, 1), (-1, -1), (-1, 1)]
    for dr, dc in set(move_dirs):
        nr, nc = r + dr, c + dc
        if 0 <= nr < 8 and 0 <= nc < 8 and board[nr][nc] == EMPTY:
            moves.append(((r, c), (nr, nc)))
        mid_r, mid_c = r + dr, c + dc
        end_r, end_c = r + 2 * dr, c + 2 * dc
        if 0 <= end_r < 8 and 0 <= end_c < 8 and board[end_r][end_c] == EMPTY:
            opponent_piece = board[mid_r][mid_c]
            if opponent_piece != EMPTY and opponent_piece[0] != player:
                capture_moves.append(((r, c), (end_r, end_c)))


def make_move(board, move):
    start, end = move
    r1, c1 = start
    r2, c2 = end
    new_board = copy.deepcopy(board)
    piece = new_board[r1][c1]
    new_board[r2][c2] = piece
    new_board[r1][c1] = EMPTY
    if abs(r1 - r2) == 2:
        mid_r, mid_c = (r1 + r2) // 2, (c1 + c2) // 2
        new_board[mid_r][mid_c] = EMPTY
    if (piece == WHITE and r2 == 0) or (piece == BLACK and r2 == 7):
        new_board[r2][c2] = piece + 'K'
    return new_board


# --- Lógica de la IA (con Paralelismo y Concurrencia) ---

def evaluate_board(board):
    board_tuple = tuple(map(tuple, board))
    if board_tuple in memoization_cache:
        return memoization_cache[board_tuple]
    score = 0
    for r in range(8):
        for c in range(8):
            piece = board[r][c]
            if piece == WHITE:
                score += 1
            elif piece == BLACK:
                score -= 1
            elif piece == WHITE_KING:
                score += 2
            elif piece == BLACK_KING:
                score -= 2
    memoization_cache[board_tuple] = score
    return score


def find_best_move(board, player, search_function):
    possible_moves = get_possible_moves(board, player)
    if not possible_moves: return None
    return search_function(board, possible_moves, player)


def sequential_search(board, possible_moves, player):

    best_move = None
    best_value = float('-inf') if player == WHITE else float('inf')
    for move in possible_moves:
        temp_board = make_move(board, move)
        value = evaluate_board(temp_board)
        if player == WHITE:
            if value > best_value: best_value, best_move = value, move
        else:
            if value < best_value: best_value, best_move = value, move
    return best_move




def evaluate_move_for_parallel(args):
    """
    Función de trabajo (worker) para multiprocessing.
    Debe estar en el nivel superior para ser 'picklable'.
    """
    board, move = args
    temp_board = make_move(board, move)
    value = evaluate_board(temp_board)
    return (value, move)


def parallel_search_multiprocessing(board, possible_moves, player):
    """Búsqueda paralela real usando procesos y un patrón map-reduce."""
    best_move = None

    # Preparamos los argumentos para cada proceso de trabajo
    tasks = [(board, move) for move in possible_moves]

    with ProcessPoolExecutor() as executor:
        # map distribuye las tareas a los procesos y recoge los resultados
        results = list(executor.map(evaluate_move_for_parallel, tasks))

    # El proceso principal encuentra el mejor resultado después de que todos terminan
    if player == WHITE:
        # Busca el valor máximo
        best_value, best_move = max(results, key=lambda item: item[0])
    else:  # player == BLACK
        # Busca el valor mínimo
        best_value, best_move = min(results, key=lambda item: item[0])

    return best_move


# -----------------------------------------------------------

def computer_move(board, player):
    print(f"Turno de la IA ({player}). Pensando...")
    # Ahora usamos la búsqueda con paralelismo real
    best_move = find_best_move(board, player, parallel_search_multiprocessing)

    if best_move:
        print(f"IA ({player}) mueve de {to_algebraic(best_move[0])} a {to_algebraic(best_move[1])}")
        return make_move(board, best_move)
    else:
        return None


# --- Interfaz de Usuario y Flujo del Juego (sin cambios) ---

def to_algebraic(pos):
    r, c = pos
    return f"{'ABCDEFGH'[c]}{8 - r}"


def from_algebraic(notation):
    try:
        notation = notation.upper()
        c = 'ABCDEFGH'.index(notation[0])
        r = 8 - int(notation[1])
        return r, c
    except (ValueError, IndexError):
        return None


def get_player_move(board, player):
    possible_moves = get_possible_moves(board, player)
    if not possible_moves: return None
    while True:
        print("Tus movimientos posibles:")
        for i, move in enumerate(possible_moves):
            print(f"  {i + 1}: {to_algebraic(move[0])} a {to_algebraic(move[1])}")
        try:
            choice = input("Elige el número de tu movimiento o ingresa el movimiento (ej. A3-B4): ").strip()
            if choice.isdigit() and 1 <= int(choice) <= len(possible_moves):
                return possible_moves[int(choice) - 1]
            if '-' in choice:
                start_str, end_str = choice.split('-')
                move_tuple = (from_algebraic(start_str.strip()), from_algebraic(end_str.strip()))
                if move_tuple in possible_moves: return move_tuple
            print("\n*** Movimiento inválido. Inténtalo de nuevo. ***\n")
        except Exception as e:
            print(f"\n*** Entrada incorrecta: {e}. Inténtalo de nuevo. ***\n")



def play_game():
    """Bucle principal del juego, ahora con soporte para capturas múltiples."""
    board = initialize_board()
    current_player = WHITE

    while True:
        print_board(board)

        possible_moves = get_possible_moves(board, current_player)
        if not possible_moves:
            winner = BLACK if current_player == WHITE else WHITE
            print(f"\n¡Juego terminado! El jugador {current_player} no tiene movimientos.")
            print(f"¡El ganador es el jugador {winner}!")
            break

        move = None
        if current_player == WHITE:  # Jugador Humano
            print(f"Turno del jugador humano ({WHITE})")
            move = get_player_move(board, WHITE)
        else:  # Jugador IA
            print(f"Turno de la IA ({BLACK}). Pensando...")
            move = find_best_move(board, BLACK, parallel_search_multiprocessing)
            if move:
                print(f"IA ({BLACK}) mueve de {to_algebraic(move[0])} a {to_algebraic(move[1])}")

        if not move:
            # Esto sucede si el jugador no tiene movimientos, aunque ya se comprueba arriba.
            # Es una doble seguridad.
            continue

        # Realizamos el primer movimiento del turno
        start_pos, end_pos = move
        board = make_move(board, move)

        ### INICIO DE LA LÓGICA DE CAPTURA MÚLTIPLE ###
        # Verificamos si el movimiento fue una captura (un salto de 2 casillas)
        is_capture = abs(start_pos[0] - end_pos[0]) == 2

        if is_capture:
            # Si fue una captura, buscamos más capturas desde la nueva posición
            further_captures = get_captures_from_position(board, end_pos)

            # Mientras haya más capturas posibles, el turno continúa
            while further_captures:
                print_board(board)
                print(f"¡Captura múltiple! Debes seguir capturando con la pieza en {to_algebraic(end_pos)}")

                next_move = None
                if current_player == WHITE:  # Turno del humano para la siguiente captura
                    next_move = get_player_move(board, WHITE)  # get_player_move mostrará solo las capturas disponibles
                else:  # Turno de la IA para la siguiente captura
                    next_move = find_best_move(board, BLACK, parallel_search_multiprocessing)
                    if next_move:
                        print(
                            f"IA ({BLACK}) continúa capturando de {to_algebraic(next_move[0])} a {to_algebraic(next_move[1])}")

                if not next_move or next_move not in further_captures:
                    print("Movimiento de captura múltiple inválido. Se seleccionará uno automáticamente.")
                    next_move = further_captures[0]

                # Realizamos la siguiente captura y actualizamos la posición final
                board = make_move(board, next_move)
                end_pos = next_move[1]

                # Buscamos de nuevo desde la última posición
                further_captures = get_captures_from_position(board, end_pos)

        ### FIN DE LA LÓGICA DE CAPTURA MÚLTIPLE ###

        # El turno solo cambia cuando la secuencia de capturas ha terminado
        current_player = BLACK if current_player == WHITE else WHITE

# --- Comparación de Tiempos (Actualizada) ---

def compare_search_times():
    print("\n--- Comparación de Tiempos de Búsqueda ---")
    board = initialize_board()

    # Secuencial
    start_time = time.time()
    find_best_move(board, WHITE, sequential_search)
    end_time = time.time()
    print(f"Búsqueda Secuencial:            {end_time - start_time:.6f} segundos.")

    # Paralelismo real (Multiprocessing)
    start_time = time.time()
    find_best_move(board, WHITE, parallel_search_multiprocessing)
    end_time = time.time()
    print(f"Paralelismo (multiprocessing):  {end_time - start_time:.6f} segundos.")
    print("------------------------------------------")


if __name__ == "__main__":
    compare_search_times()
    play_game()
